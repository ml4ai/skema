mkdir -p /tmp/automates
FLASK_ENV=development FLASK_APP=app flask run
