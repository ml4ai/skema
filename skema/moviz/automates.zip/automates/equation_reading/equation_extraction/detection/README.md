# equation detection

    docker build -t maskrcnn-gpu .
    git clone git@github.com:matterport/Mask_RCNN.git
