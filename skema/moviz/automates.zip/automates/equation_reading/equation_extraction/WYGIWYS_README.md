## Github repo:

    https://github.com/harvardnlp/im2markup

## Data
Can be downloaded from:
    
    https://zenodo.org/record/56198#.XDT2oafMzyV


## Pretrained model
Download with:
    
    mkdir -p model/latex; wget -P model/latex/ http://lstm.seas.harvard.edu/latex/model/latex/final-model


