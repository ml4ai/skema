This directory contains components for:

- Analyzing a restricted subset of FORTRAN source code,
- Translating it to a restricted subset of Python
- Export program analysis as a JSON object with associated lambda functions
